import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'CAP AI — Trợ lý AI của bạn', description: 'Trò chuyện, học tập và sáng tạo cùng CAP AI.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="vi"><body>{children}</body></html>; }
