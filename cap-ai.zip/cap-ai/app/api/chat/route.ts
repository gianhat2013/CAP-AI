import OpenAI from 'openai';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'Máy chủ chưa được cấu hình OPENAI_API_KEY.' }, { status: 503 });
    }
    const body = await req.json();
    const messages = body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return NextResponse.json({ error: 'Tin nhắn không hợp lệ.' }, { status: 400 });
    }
    const safeMessages = messages.filter((m: any) => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string')
      .slice(-20).map((m: any) => ({ role: m.role, content: m.content.slice(0, 6000) }));
    if (!safeMessages.length) return NextResponse.json({ error: 'Hãy nhập tin nhắn.' }, { status: 400 });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      messages: [{ role: 'system', content: 'Bạn là CAP AI, trợ lý thân thiện, hữu ích. Trả lời bằng tiếng Việt nếu người dùng dùng tiếng Việt. Giải thích dễ hiểu, không bịa khi không biết.' }, ...safeMessages],
      max_tokens: 900,
    });
    return NextResponse.json({ reply: response.choices[0]?.message?.content || 'Mình chưa tạo được câu trả lời.' });
  } catch (e) {
    console.error('CAP AI chat error:', e);
    return NextResponse.json({ error: 'Có lỗi khi gọi AI. Kiểm tra cấu hình API và thử lại.' }, { status: 500 });
  }
}
