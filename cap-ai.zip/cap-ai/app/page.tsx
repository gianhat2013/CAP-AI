'use client';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';

type Msg = { role: 'user' | 'assistant'; content: string };
export default function Home() {
  const [messages, setMessages] = useState<Msg[]>([{ role: 'assistant', content: 'Chào mừng đến với CAP AI! 👋\n\nTao có thể giúp mày học tập, viết code, giải đáp câu hỏi và lên ý tưởng. Hôm nay mình làm gì nào?' }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [accountOpen, setAccountOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  useEffect(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, loading]);
  async function send(e?: FormEvent) {
    e?.preventDefault(); const text = input.trim(); if (!text || loading) return;
    const next: Msg[] = [...messages, { role: 'user', content: text }]; setMessages(next); setInput(''); setLoading(true);
    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: next.slice(1) }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Không thể kết nối AI.');
      setMessages(v => [...v, { role: 'assistant', content: data.reply }]);
    } catch (err) { setMessages(v => [...v, { role: 'assistant', content: `⚠️ ${err instanceof Error ? err.message : 'Đã có lỗi xảy ra.'}` }]); }
    finally { setLoading(false); }
  }
  async function auth(action: 'signin' | 'signup') {
    setAuthMessage('Đang xử lý...'); if (!supabase) { setAuthMessage('Chưa bật đăng nhập. Hãy cấu hình Supabase theo README.md.'); return; }
    const result = action === 'signup' ? await supabase.auth.signUp({ email, password }) : await supabase.auth.signInWithPassword({ email, password });
    setAuthMessage(result.error?.message || (action === 'signup' ? 'Kiểm tra email để xác nhận tài khoản nếu được yêu cầu.' : 'Đăng nhập thành công!'));
    if (!result.error && action === 'signin') setAccountOpen(false);
  }
  async function share() { try { if (navigator.share) await navigator.share({ title: 'CAP AI', text: 'Thử CAP AI nhé!', url: location.href }); else { await navigator.clipboard.writeText(location.href); alert('Đã sao chép link website!'); } } catch {} }
  return <main className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-icon">✳</div><div><b>CAP AI</b><small>YOUR AI COMPANION</small></div></div>
      <button className="new-chat" onClick={() => setMessages([{ role: 'assistant', content: 'Cuộc trò chuyện mới! 👋 Mày muốn hỏi gì?' }])}>＋ <span>Cuộc trò chuyện mới</span></button>
      <div className="side-label">KHÁM PHÁ</div><button className="side-item" onClick={() => setInput('Giải thích một bài học thật dễ hiểu')}>✧ <span>Học tập</span></button><button className="side-item" onClick={() => setInput('Hãy giúp tôi viết code một website')}>⌘ <span>Lập trình</span></button><button className="side-item" onClick={() => setInput('Gợi ý ý tưởng sáng tạo cho tôi')}>◇ <span>Sáng tạo</span></button>
      <div className="sidebar-bottom"><div className="profile"><div className="avatar">{user?.email?.[0]?.toUpperCase() || 'U'}</div><div className="profile-text"><b>{user?.email || 'Khách truy cập'}</b><small>{user ? 'Tài khoản CAP AI' : 'Đang dùng miễn phí'}</small></div><button className="dots" onClick={() => setAccountOpen(true)}>•••</button></div></div>
    </aside>
    <section className="main-panel"><header className="topbar"><div className="mobile-brand"><span className="brand-icon">✳</span><b>CAP AI</b></div><div className="model-pill"><span className="green-dot"/> CAP AI <span className="muted">· Trợ lý thông minh</span></div><div className="top-actions"><button className="icon-btn" aria-label="Chia sẻ" onClick={share}>↗</button><button className="login-btn" onClick={() => setAccountOpen(true)}>{user ? 'Tài khoản' : 'Đăng nhập'}</button></div></header>
      <div className="chat-area"><div className="chat-content">{messages.length < 2 && <div className="welcome"><div className="orb"><span>✳</span></div><div className="eyebrow">TRÍ TUỆ NHÂN TẠO CỦA BẠN</div><h1>Chào mày, hôm nay<br/><span>mình tạo ra điều gì?</span></h1><p>Hỏi bất cứ điều gì. CAP AI sẵn sàng cùng mày khám phá ý tưởng mới.</p><div className="suggestions"><button onClick={() => setInput('Giải thích AI là gì bằng ví dụ dễ hiểu')}>✧ <span><b>Giải thích dễ hiểu</b><small>Học điều mới mỗi ngày</small></span><i>↗</i></button><button onClick={() => setInput('Viết cho tôi một website đơn giản')}>⌘ <span><b>Viết code</b><small>Bắt đầu một dự án mới</small></span><i>↗</i></button><button onClick={() => setInput('Cho tôi 5 ý tưởng video gaming thú vị')}>◇ <span><b>Lên ý tưởng</b><small>Khơi nguồn sáng tạo</small></span><i>↗</i></button></div></div>}
      <div className="messages">{messages.map((m, i) => <div key={i} className={`message ${m.role}`}><div className="message-avatar">{m.role === 'assistant' ? '✳' : (user?.email?.[0]?.toUpperCase() || 'U')}</div><div className="message-body"><div className="message-name">{m.role === 'assistant' ? 'CAP AI' : 'Bạn'}</div><div className="message-text">{m.content}</div>{m.role === 'assistant' && <button className="copy-btn" onClick={() => navigator.clipboard?.writeText(m.content)}>▢ Sao chép</button>}</div></div>)}{loading && <div className="message assistant"><div className="message-avatar">✳</div><div className="message-body"><div className="message-name">CAP AI</div><div className="typing"><span/><span/><span/></div></div></div>}<div ref={bottomRef}/></div></div></div>
      <div className="composer-wrap"><form className="composer" onSubmit={send}><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Nhắn tin cho CAP AI..." rows={1} maxLength={6000}/><div className="composer-bottom"><span>↵ Enter để gửi · Shift + Enter xuống dòng</span><button className="send-btn" disabled={!input.trim() || loading} aria-label="Gửi tin nhắn">↑</button></div></form><p className="disclaimer">CAP AI có thể mắc lỗi. Hãy kiểm tra lại thông tin quan trọng.</p></div>
    </section>
    {accountOpen && <div className="modal-backdrop" onClick={() => setAccountOpen(false)}><div className="account-modal" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setAccountOpen(false)}>×</button><div className="orb small-orb">✳</div><h2>{user ? 'Tài khoản của bạn' : 'Chào mừng đến CAP AI'}</h2><p>{user ? user.email : 'Đăng nhập hoặc tạo tài khoản để bắt đầu.'}</p>{!user && <><label>Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="ban@email.com"/><label>Mật khẩu (ít nhất 6 ký tự)</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"/><div className="auth-buttons"><button onClick={() => void auth('signin')}>Đăng nhập</button><button onClick={() => void auth('signup')}>Tạo tài khoản</button></div></>}{user && <button className="logout-btn" onClick={async () => { await supabase?.auth.signOut(); setAccountOpen(false); }}>Đăng xuất</button>}<p className="auth-message">{authMessage}</p>{!supabase && <p className="setup-note">Tài khoản cần cấu hình Supabase — xem README.md.</p>}</div></div>}
  </main>;
}
